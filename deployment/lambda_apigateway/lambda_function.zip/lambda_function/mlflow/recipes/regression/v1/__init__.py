from mlflow.recipes.regression.v1.recipe import (
    RegressionRecipe as RecipeImpl,
)

__all__ = ["RecipeImpl"]
