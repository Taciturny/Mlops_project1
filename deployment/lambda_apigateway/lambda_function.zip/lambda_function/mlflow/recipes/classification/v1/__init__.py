from mlflow.recipes.classification.v1.recipe import (
    ClassificationRecipe as RecipeImpl,
)

__all__ = ["RecipeImpl"]
